Downloaded from:
https://mcmodels.net/

Made by Voxelspawns
____   ____                     .__         _________                                       
\   \ /   /____ ___  ___  ____  |  |       /   _____/______ _____  __  _  __ ____    ______ 
 \   Y   //  _ \\  \/  /_/ __ \ |  |       \_____  \ \____ \\__  \ \ \/ \/ //    \  /  ___/ 
  \     /(  <_> )>    < \  ___/ |  |__     /        \|  |_> >/ __ \_\     /|   |  \ \___ \  
   \___/  \____//__/\_ \ \___  >|____/    /_______  /|   __/(____  / \/\_/ |___|  //____  > 
                      \/     \/                   \/ |__|        \/             \/      \/  
                         

---------------------------------------------------------------------------------------------

Commands to get the items ingame:

/minecraft:give Elo106 minecraft:netherite_sword{CustomModelData:1}

Replace "Elo106" with your name.

---------------------------------------------------------------------------------------------

If you have any questions or need help join
the mcmodels.net or voxelspawns discord.

mcmodels:
https://mcmodels.net/

voxelspawns:
https://discord.com/invite/yDuD9HNzAB
#89ff96f601e1c87e2ee26026055b9cf3